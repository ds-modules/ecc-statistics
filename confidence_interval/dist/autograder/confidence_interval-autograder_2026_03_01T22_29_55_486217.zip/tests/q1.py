OK_FORMAT = True

test = {   'name': 'q1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert np.isclose(z, stats.norm.ppf(1 - 0.05 / 2))\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> standard_error = sample_std / np.sqrt(n)\n'
                                               '>>> assert np.isclose(ci_lower, sample_mean - z * standard_error)\n'
                                               '>>> assert np.isclose(ci_upper, sample_mean + z * standard_error)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
