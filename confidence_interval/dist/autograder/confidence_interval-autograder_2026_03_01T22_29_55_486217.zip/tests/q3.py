OK_FORMAT = True

test = {   'name': 'q3',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert np.isclose(ci_drop_lower, np.percentile(boot_drop_means, 2.5))\n'
                                               '>>> assert np.isclose(ci_drop_upper, np.percentile(boot_drop_means, 97.5))\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
