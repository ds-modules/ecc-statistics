OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> assert len(boot_means) == 5000\n', 'hidden': False, 'locked': False},
                                   {   'code': '>>> assert np.isclose(boot_ci_lower, np.percentile(boot_means, 2.5))\n>>> assert np.isclose(boot_ci_upper, np.percentile(boot_means, 97.5))\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
